-- Thrive: Social Fitness Platform Extension
-- Adds: conversations, posts, duels, notifications, social activities
-- This extends the existing 0001_social.sql schema

-- ============================================
-- CONVERSATIONS
-- A conversation is a thread between friends.
-- Messages reference conversations rather than just recipient_id,
-- so we can show conversation lists, unread counts, etc.
-- ============================================

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  name text, -- optional group name (currently unused, reserved for future)
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.conversations enable row level security;

do $$ begin
  create policy "you see your own conversations" on public.conversations
    for select using (
      exists (
        select 1 from public.conversation_members
        where conversation_members.conversation_id = public.conversations.id
        and conversation_members.user_id = auth.uid()
      )
    );
  create policy "you create conversations" on public.conversations
    for insert with check (auth.uid() = id); -- created by you
  create policy "you update your conversations" on public.conversations
    for update using (auth.uid() = id);
exception when duplicate_object then null; end $$;

-- Conversation members: who is in a conversation
create table if not exists public.conversation_members (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  joined_at timestamptz not null default now(),
  unique(conversation_id, user_id)
);

alter table public.conversation_members enable row level security;

do $$ begin
  create policy "you see members of your conversations" on public.conversation_members
    for select using (
      exists (
        select 1 from public.conversation_members cm
        where cm.conversation_id = public.conversation_members.conversation_id
        and cm.user_id = auth.uid()
      )
    );
  create policy "you add yourself to conversations" on public.conversation_members
    for insert with check (auth.uid() = user_id);
  create policy "you remove yourself from conversations" on public.conversation_members
    for delete using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

-- Update messages table to reference conversations
-- First, add the column (nullable for existing messages)
alter table public.messages
  add column if not exists conversation_id uuid references public.conversations on delete set null;

-- Create index for efficient conversation lookups
create index if not exists messages_conversation_idx
  on public.messages (conversation_id, created_at asc);

-- Function to get or create a conversation between two users
create or replace function public.get_or_create_conversation(user_a uuid, user_b uuid)
returns uuid language sql security definer set search_path = public as $$
  select coalesce(
    (
      select cm.conversation_id
      from public.conversation_members cm
      where cm.user_id = least(user_a, user_b)
      and exists (
        select 1 from public.conversation_members cm2
        where cm2.conversation_id = cm.conversation_id
        and cm2.user_id = greatest(user_a, user_b)
      )
      limit 1
    ),
    (
      with new_conv as (
        insert into public.conversations (id) values (gen_random_uuid())
        returning id
      )
      select new_conv.id from new_conv
      where not exists (
        select 1 from public.conversation_members
        where conversation_id = new_conv.id
      )
      union all
      select cm.conversation_id
      from public.conversation_members cm
      cross join (select gen_random_uuid() as new_id) new
      where cm.user_id = least(user_a, user_b)
      and not exists (
        select 1 from public.conversation_members cm2
        where cm2.conversation_id = cm.conversation_id
        and cm2.user_id = greatest(user_a, user_b)
      )
      limit 1
    )
  );
$$;

-- Make sure realtime is enabled for conversations
do $$ begin
  alter publication supabase_realtime add table public.conversations;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.conversation_members;
exception when duplicate_object then null; end $$;

-- ============================================
-- DUELS (1v1 competitions)
-- A duel is a direct competition between two friends.
-- Unlike challenges (which can be personal/improvement),
-- duels are always 1v1 and have a specific structure.
-- ============================================

create type public.duel_status as enum ('pending', 'accepted', 'declined', 'in_progress', 'completed', 'expired');
create type public.duel_kind as enum ('reps', 'form', 'time', 'max_reps');

create table if not exists public.duels (
  id uuid primary key default gen_random_uuid(),
  challenger_id uuid not null references auth.users on delete cascade,
  opponent_id uuid not null references auth.users on delete cascade,
  exercise_id text not null,
  kind public.duel_kind not null,
  -- For time-based duels: duration in seconds
  duration_seconds int check (duration_seconds > 0),
  -- Target for rep challenges (e.g., "most reps in 60 seconds")
  target_reps int,
  status public.duel_status not null default 'pending',
  challenger_attempt_id uuid references public.duel_attempts on delete set null,
  opponent_attempt_id uuid references public.duel_attempts on delete set null,
  winner_id uuid references auth.users on delete set null,
  created_at timestamptz not null default now(),
  started_at timestamptz,
  completed_at timestamptz,
  constraint duels_not_self check (challenger_id <> opponent_id)
);

create index if not exists duels_by_challenger on public.duels (challenger_id, status);
create index if not exists duels_by_opponent on public.duels (opponent_id, status);

alter table public.duels enable row level security;

do $$ begin
  create policy "you see duels you are in" on public.duels
    for select using (auth.uid() = challenger_id or auth.uid() = opponent_id);

  create policy "you create duels with friends" on public.duels
    for insert with check (
      auth.uid() = challenger_id
      and public.are_friends(challenger_id, opponent_id)
      and not public.is_blocked(challenger_id, opponent_id)
    );

  create policy "either side may update" on public.duels
    for update using (auth.uid() = challenger_id or auth.uid() = opponent_id)
    with check (auth.uid() = challenger_id or auth.uid() = opponent_id);

  create policy "challenger may delete pending duels" on public.duels
    for delete using (auth.uid() = challenger_id and status = 'pending');
exception when duplicate_object then null; end $$;

-- Duel attempts: each player's attempt at a duel
create table if not exists public.duel_attempts (
  id uuid primary key default gen_random_uuid(),
  duel_id uuid not null references public.duels on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  workout_id uuid references public.workouts on delete set null,
  -- The measured result depending on duel kind
  reps int check (reps >= 0),
  form_score int check (form_score between 0 and 100),
  duration_seconds int,
  -- When the attempt was recorded
  recorded_at timestamptz not null default now(),
  unique(duel_id, user_id)
);

create index if not exists duel_attempts_by_duel on public.duel_attempts (duel_id);

alter table public.duel_attempts enable row level security;

do $$ begin
  create policy "you see attempts in your duels" on public.duel_attempts
    for select using (
      exists (
        select 1 from public.duels
        where duels.id = duel_id
        and (duels.challenger_id = auth.uid() or duels.opponent_id = auth.uid())
      )
    );

  create policy "you create your own attempts" on public.duel_attempts
    for insert with check (auth.uid() = user_id);

  create policy "you update your own attempts" on public.duel_attempts
    for update using (auth.uid() = user_id);

  create policy "you delete your own attempts" on public.duel_attempts
    for delete using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

-- Realtime for duels
do $$ begin
  alter publication supabase_realtime add table public.duels;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.duel_attempts;
exception when duplicate_object then null; end $$;

-- ============================================
-- NOTIFICATIONS
-- Real-time notifications for social events
-- ============================================

create type public.notification_type as enum (
  'friend_request_sent',
  'friend_request_accepted',
  'friend_request_declined',
  'friend_added',
  'message_received',
  'duel_invitation',
  'duel_accepted',
  'duel_declined',
  'duel_completed',
  'challenge_invitation',
  'challenge_accepted',
  'challenge_completed',
  'friend_pr',
  'friend_streak',
  'post_liked',
  'post_comment',
  'workout_shared',
  'duel_won',
  'duel_lost'
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  type public.notification_type not null,
  -- The subject: who/what triggered this
  from_user_id uuid references auth.users on delete set null,
  -- Related entity IDs (optional context)
  conversation_id uuid references public.conversations on delete set null,
  duel_id uuid references public.duels on delete set null,
  challenge_id uuid references public.challenges on delete set null,
  workout_id uuid references public.workouts on delete set null,
  post_id uuid references public.posts on delete set null,
  -- Read state
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists notifications_by_user on public.notifications (user_id, created_at desc);
create index if not exists notifications_unread on public.notifications (user_id) where read_at is null;

alter table public.notifications enable row level security;

do $$ begin
  create policy "you see your own notifications" on public.notifications
    for select using (auth.uid() = user_id);

  create policy "notifications are created by the system" on public.notifications
    for insert with check (auth.uid() = user_id);

  create policy "you mark your notifications read" on public.notifications
    for update using (auth.uid() = user_id)
    with check (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

-- Mark all notifications as read for a user
create or replace function public.mark_notifications_read()
returns void language sql security definer set search_path = public as $$
  update public.notifications
  set read_at = now()
  where user_id = auth.uid()
  and read_at is null;
$$;

do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;

-- ============================================
-- POSTS (Feed items)
-- Posts can be manually created or auto-generated from activities
-- ============================================

create type public.post_type as enum (
  'workout_completed',
  'personal_record',
  'streak_milestone',
  'duel_won',
  'duel_lost',
  'challenge_completed',
  'manual'
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  type public.post_type not null,
  -- The content depends on type
  title text not null,
  body text,
  -- Metrics depending on type
  exercise_id text,
  reps int,
  form_score int check (form_score between 0 and 100),
  streak_days int,
  -- Context
  workout_id uuid references public.workouts on delete set null,
  duel_id uuid references public.duels on delete set null,
  challenge_id uuid references public.challenges on delete set null,
  -- Engagement
  likes_count int not null default 0 check (likes_count >= 0),
  comments_count int not null default 0 check (comments_count >= 0),
  -- Visibility
  visibility text not null default 'friends'
    check (visibility in ('private', 'friends', 'public')),
  created_at timestamptz not null default now()
);

create index if not exists posts_by_user on public.posts (user_id, created_at desc);
create index if not exists posts_feed on public.posts (created_at desc)
  where visibility <> 'private';

alter table public.posts enable row level security;

do $$ begin
  create policy "you see your own posts" on public.posts
    for select using (auth.uid() = user_id);

  create policy "friends see shared posts" on public.posts
    for select using (
      visibility = 'friends'
      and public.are_friends(auth.uid(), user_id)
      and not public.is_blocked(auth.uid(), user_id)
    );

  create policy "anyone sees public posts" on public.posts
    for select using (
      visibility = 'public'
      and auth.uid() is not null
      and not public.is_blocked(auth.uid(), user_id)
    );

  create policy "you create posts" on public.posts
    for insert with check (auth.uid() = user_id);

  create policy "you update your posts" on public.posts
    for update using (auth.uid() = user_id)
    with check (auth.uid() = user_id);

  create policy "you delete your posts" on public.posts
    for delete using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

do $$ begin
  alter publication supabase_realtime add table public.posts;
exception when duplicate_object then null; end $$;

-- ============================================
-- POST LIKES
-- ============================================

create table if not exists public.post_likes (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  created_at timestamptz not null default now(),
  unique(post_id, user_id)
);

create index if not exists post_likes_by_post on public.post_likes (post_id);

alter table public.post_likes enable row level security;

do $$ begin
  create policy "you see likes on posts you can see" on public.post_likes
    for select using (
      exists (
        select 1 from public.posts
        where posts.id = post_likes.post_id
        and (
          posts.user_id = auth.uid()
          or posts.visibility = 'friends'
            and public.are_friends(auth.uid(), posts.user_id)
          or posts.visibility = 'public'
        )
      )
    );

  create policy "you like posts you can see" on public.post_likes
    for insert with check (
      auth.uid() = user_id
      and exists (
        select 1 from public.posts
        where posts.id = post_likes.post_id
        and (
          posts.user_id = auth.uid()
          or posts.visibility = 'friends'
            and public.are_friends(auth.uid(), posts.user_id)
          or posts.visibility = 'public'
        )
      )
    );

  create policy "you unlike posts" on public.post_likes
    for delete using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

-- ============================================
-- POST COMMENTS
-- ============================================

create table if not exists public.post_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts on delete cascade,
  user_id uuid not null references auth.users on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);

create index if not exists post_comments_by_post on public.post_comments (post_id, created_at asc);

alter table public.post_comments enable row level security;

do $$ begin
  create policy "you see comments on posts you can see" on public.post_comments
    for select using (
      exists (
        select 1 from public.posts
        where posts.id = post_comments.post_id
        and (
          posts.user_id = auth.uid()
          or posts.visibility = 'friends'
            and public.are_friends(auth.uid(), posts.user_id)
          or posts.visibility = 'public'
        )
      )
    );

  create policy "you comment on posts you can see" on public.post_comments
    for insert with check (
      auth.uid() = user_id
      and exists (
        select 1 from public.posts
        where posts.id = post_comments.post_id
        and (
          posts.user_id = auth.uid()
          or posts.visibility = 'friends'
            and public.are_friends(auth.uid(), posts.user_id)
          or posts.visibility = 'public'
        )
      )
    );

  create policy "you delete your comments" on public.post_comments
    for delete using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

do $$ begin
  alter publication supabase_realtime add table public.post_comments;
exception when duplicate_object then null; end $$;

-- ============================================
-- SOCIAL ACTIVITIES (for auto-generating feed posts)
-- This tracks meaningful fitness events that can become posts
-- ============================================

create type public.activity_type as enum (
  'workout_completed',
  'personal_record',
  'streak_reached',
  'duel_won',
  'duel_completed',
  'challenge_completed'
);

create table if not exists public.social_activities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users on delete cascade,
  type public.activity_type not null,
  -- Data about the activity
  exercise_id text,
  reps int,
  form_score int check (form_score between 0 and 100),
  streak_days int,
  -- Related entities
  workout_id uuid references public.workouts on delete set null,
  duel_id uuid references public.duels on delete set null,
  challenge_id uuid references public.challenges on delete set null,
  -- Whether this has been turned into a post
  post_id uuid references public.posts on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists social_activities_by_user on public.social_activities (user_id, created_at desc);

alter table public.social_activities enable row level security;

do $$ begin
  create policy "you see your own activities" on public.social_activities
    for select using (auth.uid() = user_id);

  create policy "friends see shared activities" on public.social_activities
    for select using (
      exists (
        select 1 from public.social_activities sa
        where sa.user_id = public.social_activities.user_id
        and (
          sa.id in (
            select sa2.id from public.social_activities sa2
            where sa2.user_id = public.social_activities.user_id
            and exists (
              select 1 from public.posts p
              where p.id = sa2.post_id
              and p.visibility = 'friends'
              and public.are_friends(auth.uid(), sa2.user_id)
            )
          )
          or sa.user_id = auth.uid()
        )
      )
    );

  create policy "you create your own activities" on public.social_activities
    for insert with check (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

-- ============================================
-- Helper functions
-- ============================================

-- Create a notification
create or replace function public.create_notification(
  p_user_id uuid,
  p_type public.notification_type,
  p_from_user_id uuid default null,
  p_conversation_id uuid default null,
  p_duel_id uuid default null,
  p_challenge_id uuid default null,
  p_workout_id uuid default null,
  p_post_id uuid default null
)
returns uuid language sql security definer set search_path = public as $$
  insert into public.notifications (
    user_id, type, from_user_id, conversation_id, duel_id,
    challenge_id, workout_id, post_id
  ) values (
    p_user_id, p_type, p_from_user_id, p_conversation_id, p_duel_id,
    p_challenge_id, p_workout_id, p_post_id
  )
  returning id;
$$;

-- Create a post from an activity
create or replace function public.create_post_from_activity(
  p_activity_id uuid,
  p_title text,
  p_body text default null
)
returns uuid language sql security definer set search_path = public as $$
  declare
    v_activity public.social_activities%rowtype;
    v_post_id uuid;
  begin
    select * into v_activity from public.social_activities where id = p_activity_id;

    insert into public.posts (
      user_id, type, title, body, exercise_id, reps, form_score,
      streak_days, workout_id, duel_id, challenge_id, visibility
    ) values (
      v_activity.user_id,
      case v_activity.type
        when 'workout_completed' then 'workout_completed'
        when 'personal_record' then 'personal_record'
        when 'streak_reached' then 'streak_milestone'
        when 'duel_won' then 'duel_won'
        when 'duel_completed' then 'duel_lost'
        when 'challenge_completed' then 'challenge_completed'
      end,
      p_title,
      p_body,
      v_activity.exercise_id,
      v_activity.reps,
      v_activity.form_score,
      v_activity.streak_days,
      v_activity.workout_id,
      v_activity.duel_id,
      v_activity.challenge_id,
      'friends'
    ) returning id into v_post_id;

    update public.social_activities
    set post_id = v_post_id
    where id = p_activity_id;

    return v_post_id;
  end;
$$;

-- Like/unlike a post (toggle)
create or replace function public.toggle_post_like(p_post_id uuid)
returns boolean language sql security definer set search_path = public as $$
  declare
    v_count int;
  begin
    -- Try to delete existing like
    delete from public.post_likes
    where post_id = p_post_id and user_id = auth.uid();

    if found then
      -- Unliked: decrement count
      update public.posts
      set likes_count = greatest(0, likes_count - 1)
      where id = p_post_id;
      return false; -- was liked, now unliked
    else
      -- Not liked: insert and increment
      insert into public.post_likes (post_id, user_id)
      values (p_post_id, auth.uid());
      update public.posts
      set likes_count = likes_count + 1
      where id = p_post_id;
      return true; -- now liked
    end if;
  end;
$$;

-- Add comment to a post
create or replace function public.add_post_comment(
  p_post_id uuid,
  p_body text
)
returns uuid language sql security definer set search_path = public as $$
  declare
    v_comment_id uuid;
  begin
    insert into public.post_comments (post_id, user_id, body)
    values (p_post_id, auth.uid(), p_body)
    returning id into v_comment_id;

    update public.posts
    set comments_count = comments_count + 1
    where id = p_post_id;

    -- Notify post author if not self
    if exists (
      select 1 from public.posts
      where id = p_post_id and user_id <> auth.uid()
    ) then
      perform public.create_notification(
        (select user_id from public.posts where id = p_post_id),
        'post_comment',
        auth.uid(),
        p_post_id
      );
    end if;

    return v_comment_id;
  end;
$$;

-- ============================================
-- Indexes for performance
-- ============================================

create index if not exists duels_by_exercise on public.duels (exercise_id, status);
create index if not exists posts_by_type on public.posts (type, created_at desc);
create index if not exists notifications_by_type on public.notifications (type, created_at desc);

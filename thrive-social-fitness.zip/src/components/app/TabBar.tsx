/**
 * The bottom bar.
 *
 * Seven tabs for the social fitness platform.
 * The one you are on is ink; the rest are grey.
 * No pill, no tinted background — on a page this quiet, weight and colour
 * are enough to say where you are.
 */
import { Link, useRouterState } from '@tanstack/react-router';
import { CalendarDays, Dumbbell, Heart, Home, Lightning, BarChart3, Users, MessageSquare } from 'lucide-react';
import type { ComponentType } from 'react';
import { useAppState } from '@/app/appContext';

interface Tab {
  to: string;
  label: string;
  Icon: ComponentType<{ className?: string; strokeWidth?: number }>;
  owns?: string[];
}

/**
 * Eight places, and each answers one question in the social fitness platform:
 *
 * Home — what should I do today (dashboard with streak, friends, duels)
 * Train — what should I train (exercise selection and pose analysis)
 * Feed — what are my friends doing (social feed with workouts and achievements)
 * Friends — who am I training with (friend list, requests, profiles)
 * Messages — who did I hear from (real-time conversations)
 * Duels — who am I competing against (1v1 competitions)
 * Challenges — what am I working toward (longer-term goals)
 * Profile — who am I in this app (fitness identity, stats, settings)
 *
 * The coach is not a tab — it lives where questions arise (results screen,
 * home screen) rather than as a permanent destination.
 */
const TABS: Tab[] = [
  { to: '/home', label: 'Home', Icon: Home },
  { to: '/train', label: 'Train', Icon: Dumbbell, owns: ['/train'] },
  { to: '/feed', label: 'Feed', Icon: Heart },
  { to: '/friends', label: 'Friends', Icon: Users, owns: ['/friends', '/connect'] },
  { to: '/messages', label: 'Messages', Icon: MessageSquare },
  { to: '/duels', label: 'Duels', Icon: Lightning },
  { to: '/challenges', label: 'Challenges', Icon: BarChart3 },
  { to: '/profile', label: 'Profile', Icon: CalendarDays },
];

export function TabBar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { hasFigure, capturing } = useAppState();

  // Building your figure is a takeover: there is nowhere else to be yet, and
  // a bar offering empty screens would only invite you to leave.
  if (!hasFigure) return null;
  // So is filming yourself — the camera needs the height, and leaving mid-set
  // is not a thing anyone means to do.
  if (capturing) return null;

  return (
    <nav
      aria-label="Sections"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-ink/95 backdrop-blur-xl"
    >
      <ul className="mx-auto flex w-full max-w-[36rem] items-stretch px-2 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2">
        {TABS.map(({ to, label, Icon, owns }) => {
          const active = to === '/home' ? path === '/home' || path === '/' : (owns ?? [to]).some((p) => path.startsWith(p));
          return (
            <li key={to} className="flex-1">
              <Link
                to={to}
                aria-current={active ? 'page' : undefined}
                className={`relative flex min-h-[3rem] flex-col items-center justify-center gap-1 transition-colors duration-200 ${
                  active ? 'text-fg' : 'text-fg-faint hover:text-fg-muted'
                }`}
              >
                {/* A hairline over the active tab rather than a pill. */}
                <span
                  aria-hidden
                  className={`absolute -top-2.5 h-[2px] rounded-full bg-accent transition-all duration-300 ease-[var(--ease-quint)] ${
                    active ? 'w-6 opacity-100' : 'w-0 opacity-0'
                  }`}
                />
                <Icon className="size-[18px]" strokeWidth={active ? 2.2 : 1.5} />
                <span className={`text-[11px] tracking-[0.02em] ${active ? 'font-medium' : ''}`}>
                  {label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

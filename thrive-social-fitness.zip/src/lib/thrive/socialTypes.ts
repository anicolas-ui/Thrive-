/** Types for social fitness features: conversations, duels, posts, notifications */

import type { ExerciseId } from './exercises'

// ============================================
// CONVERSATIONS
// ============================================

export interface Conversation {
  id: string
  name?: string | null
  createdAt: string
  updatedAt: string
  // Computed: who we're talking to (for 1:1)
  otherUser?: SocialProfile | null
  // Computed: last message
  lastMessage?: Message | null
  // Computed: unread count
  unreadCount?: number
}

export interface ConversationMember {
  id: string
  conversationId: string
  userId: string
  joinedAt: string
}

// ============================================
// MESSAGES
// ============================================

export interface Message {
  id: string
  conversationId?: string | null
  senderId: string
  recipientId: string | null // Legacy field, will be phased out
  body: string
  workoutId?: string | null
  challengeId?: string | null
  readAt?: string | null
  createdAt: string
  // Computed
  sender?: SocialProfile | null
  workout?: SharedWorkout | null
}

// ============================================
// DUELS
// ============================================

export type DuelKind = 'reps' | 'form' | 'time' | 'max_reps'
export type DuelStatus =
  | 'pending'
  | 'accepted'
  | 'declined'
  | 'in_progress'
  | 'completed'
  | 'expired'

export interface Duel {
  id: string
  challengerId: string
  opponentId: string
  exerciseId: ExerciseId
  kind: DuelKind
  durationSeconds?: number | null
  targetReps?: number | null
  status: DuelStatus
  challengerAttemptId?: string | null
  opponentAttemptId?: string | null
  winnerId?: string | null
  createdAt: string
  startedAt?: string | null
  completedAt?: string | null
  // Computed
  challenger?: SocialProfile | null
  opponent?: SocialProfile | null
  challengerAttempt?: DuelAttempt | null
  opponentAttempt?: DuelAttempt | null
}

export interface DuelAttempt {
  id: string
  duelId: string
  userId: string
  workoutId?: string | null
  reps?: number | null
  formScore?: number | null
  durationSeconds?: number | null
  recordedAt: string
  // Computed
  user?: SocialProfile | null
  workout?: SharedWorkout | null
}

// ============================================
// NOTIFICATIONS
// ============================================

export type NotificationType =
  | 'friend_request_sent'
  | 'friend_request_accepted'
  | 'friend_request_declined'
  | 'friend_added'
  | 'message_received'
  | 'duel_invitation'
  | 'duel_accepted'
  | 'duel_declined'
  | 'duel_completed'
  | 'challenge_invitation'
  | 'challenge_accepted'
  | 'challenge_completed'
  | 'friend_pr'
  | 'friend_streak'
  | 'post_liked'
  | 'post_comment'
  | 'workout_shared'
  | 'duel_won'
  | 'duel_lost'

export interface Notification {
  id: string
  userId: string
  type: NotificationType
  fromUserId?: string | null
  conversationId?: string | null
  duelId?: string | null
  challengeId?: string | null
  workoutId?: string | null
  postId?: string | null
  readAt?: string | null
  createdAt: string
  // Computed
  fromUser?: SocialProfile | null
  // For display
  title?: string
  body?: string
  actionUrl?: string
}

// ============================================
// POSTS (Feed items)
// ============================================

export type PostType =
  | 'workout_completed'
  | 'personal_record'
  | 'streak_milestone'
  | 'duel_won'
  | 'duel_lost'
  | 'challenge_completed'
  | 'manual'

export interface Post {
  id: string
  userId: string
  type: PostType
  title: string
  body?: string | null
  exerciseId?: ExerciseId | null
  reps?: number | null
  formScore?: number | null
  streakDays?: number | null
  workoutId?: string | null
  duelId?: string | null
  challengeId?: string | null
  likesCount: number
  commentsCount: number
  visibility: 'private' | 'friends' | 'public'
  createdAt: string
  // Computed
  user?: SocialProfile | null
  // Engagement state
  isLiked?: boolean
  // Comments (for expanded view)
  comments?: PostComment[]
}

export interface PostComment {
  id: string
  postId: string
  userId: string
  body: string
  createdAt: string
  // Computed
  user?: SocialProfile | null
}

// ============================================
// SOCIAL ACTIVITIES
// ============================================

export type ActivityType =
  | 'workout_completed'
  | 'personal_record'
  | 'streak_reached'
  | 'duel_won'
  | 'duel_completed'
  | 'challenge_completed'

export interface SocialActivity {
  id: string
  userId: string
  type: ActivityType
  exerciseId?: ExerciseId | null
  reps?: number | null
  formScore?: number | null
  streakDays?: number | null
  workoutId?: string | null
  duelId?: string | null
  challengeId?: string | null
  postId?: string | null
  createdAt: string
  // Computed
  user?: SocialProfile | null
}

// ============================================
// COMBINED SOCIAL STATE
// ============================================

export interface SocialFitnessState {
  // Notifications
  notifications: Notification[]
  unreadCount: number

  // Conversations
  conversations: Conversation[]

  // Feed
  feedPosts: Post[]

  // Duels
  activeDuels: Duel[]
  pendingDuels: Duel[]

  // Activities (for feed generation)
  recentActivities: SocialActivity[]
}

/** Social fitness operations: conversations, duels, posts, notifications */

import { cloud } from './supabase'
import {
  myId,
  type SocialProfile,
  type SharedWorkout,
  type Visibility,
} from './social'
import type {
  Conversation,
  Message,
  Duel,
  DuelKind,
  DuelStatus,
  DuelAttempt,
  Notification,
  NotificationType,
  Post,
  PostType,
  PostComment,
  SocialActivity,
  ActivityType,
} from './socialTypes'
import type { ExerciseId } from './exercises'
import type { CloudResult } from './cloudAccount'

// ============================================
// OFFLINE/ERROR HELPERS
// ============================================

const offline = <T>(detail?: string): CloudResult<T> => ({
  ok: false,
  reason: 'Could not reach the account server.',
  code: 'offline',
  detail,
})

const notSignedIn = <T>(): CloudResult<T> => ({
  ok: false,
  reason: 'You are not signed in.',
  code: 'unverified',
})

// ============================================
// CONVERSATIONS
// ============================================

export async function getOrCreateCallConversation(
  otherUserId: string,
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()
  if (me === otherUserId) {
    return { ok: false, reason: 'Cannot start a conversation with yourself.', code: 'invalid' }
  }

  try {
    const { data, error } = await db.rpc('get_or_create_conversation', {
      user_a: me,
      user_b: otherUserId,
    })
    return error ? offline(error.message) : { ok: true, value: data }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function loadConversations(): Promise<Conversation[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    // Get all conversations this user is a member of
    const { data: members } = await db
      .from('conversation_members')
      .select('conversation_id')
      .eq('user_id', me)

    if (!members || members.length === 0) return []

    const convoIds = members.map((m) => m.conversation_id)

    // Get conversations with their last message
    const { data: conversations } = await db
      .from('conversations')
      .select('id, name, created_at, updated_at')
      .in('id', convoIds)
      .order('updated_at', { ascending: false })

    if (!conversations) return []

    // Get all other members (should be just one for 1:1)
    const { data: allMembers } = await db
      .from('conversation_members')
      .select('conversation_id, user_id, joined_at')
      .in('conversation_id', convoIds)

    // Get profile for other members
    const otherUserIds = allMembers
      ? allMembers
          .filter((m) => m.user_id !== me)
          .map((m) => m.user_id)
      : []

    const otherProfiles: Record<string, SocialProfile> = {}
    if (otherUserIds.length > 0) {
      const { data: profiles } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', otherUserIds)
      if (profiles) {
        for (const p of profiles) {
          otherProfiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    // Get last message for each conversation
    const { data: lastMessages } = await db
      .from('messages')
      .select(
        'id, conversation_id, sender_id, body, workout_id, challenge_id, read_at, created_at',
      )
      .in('conversation_id', convoIds)
      .order('created_at', { ascending: false })
      .limit(convoIds.length * 2) // Get more than needed in case some have no messages

    // Get unread counts
    const { data: unreadData } = await db
      .from('messages')
      .select('conversation_id, read_at')
      .in('conversation_id', convoIds)
      .neq('read_at', null)
      .eq('recipient_id', me)

    const unreadCounts: Record<string, number> = {}
    if (unreadData) {
      for (const msg of unreadData) {
        if (!unreadCounts[msg.conversation_id]) unreadCounts[msg.conversation_id] = 0
        unreadCounts[msg.conversation_id]++
      }
    }

    // Build conversation list
    const convoMap = new Map<string, Conversation>()
    for (const c of conversations) {
      convoMap.set(c.id, {
        id: c.id,
        name: c.name,
        createdAt: c.created_at,
        updatedAt: c.updated_at,
        otherUser: null,
        lastMessage: null,
        unreadCount: unreadCounts[c.id] ?? 0,
      })
    }

    // Add other users
    if (allMembers) {
      for (const m of allMembers) {
        const convo = convoMap.get(m.conversation_id)
        if (convo && m.user_id !== me) {
          convo.otherUser = otherProfiles[m.user_id] ?? null
        }
      }
    }

    // Add last messages (most recent per conversation)
    const seenConversations = new Set<string>()
    if (lastMessages) {
      for (const msg of lastMessages) {
        if (seenConversations.has(msg.conversation_id)) continue
        seenConversations.add(msg.conversation_id)
        const convo = convoMap.get(msg.conversation_id)
        if (convo) {
          convo.lastMessage = {
            id: msg.id,
            conversationId: msg.conversation_id,
            senderId: msg.sender_id,
            recipientId: msg.recipient_id,
            body: msg.body,
            workoutId: msg.workout_id,
            challengeId: msg.challenge_id,
            readAt: msg.read_at,
            createdAt: msg.created_at,
            sender: otherProfiles[msg.sender_id] ?? null,
          }
        }
      }
    }

    return Array.from(convoMap.values()).sort(
      (a, b) =>
        new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime(),
    )
  } catch {
    return []
  }
}

export async function loadConversationMessages(
  conversationId: string,
  limit = 50,
): Promise<Message[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    const { data } = await db
      .from('messages')
      .select(
        'id, conversation_id, sender_id, recipient_id, body, workout_id, challenge_id, read_at, created_at',
      )
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(limit)

    if (!data) return []

    // Get sender profiles
    const senderIds = [...new Set(data.map((m) => m.sender_id))]
    const profiles: Record<string, SocialProfile> = {}

    if (senderIds.length > 0) {
      const { data: profileData } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', senderIds)
      if (profileData) {
        for (const p of profileData) {
          profiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    // Mark messages as read
    await markMessagesRead(conversationId, me)

    return data.map((m) => ({
      id: m.id,
      conversationId: m.conversation_id,
      senderId: m.sender_id,
      recipientId: m.recipient_id,
      body: m.body,
      workoutId: m.workout_id,
      challengeId: m.challenge_id,
      readAt: m.read_at,
      createdAt: m.created_at,
      sender: profiles[m.sender_id] ?? null,
    }))
  } catch {
    return []
  }
}

export async function sendMessage(
  conversationId: string,
  body: string,
  workoutId?: string | null,
  challengeId?: string | null,
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()
  if (!body || body.trim().length === 0 || body.length > 1000) {
    return { ok: false, reason: 'Message must be between 1 and 1000 characters.', code: 'invalid' }
  }

  try {
    // Get recipient from conversation
    const { data: member } = await db
      .from('conversation_members')
      .select('user_id')
      .eq('conversation_id', conversationId)
      .neq('user_id', me)
      .maybeSingle()

    if (!member) {
      return { ok: false, reason: 'Conversation not found.', code: 'not_found' }
    }

    const { data, error } = await db
      .from('messages')
      .insert({
        conversation_id: conversationId,
        sender_id: me,
        recipient_id: member.user_id,
        body: body.trim(),
        workout_id: workoutId ?? null,
        challenge_id: challengeId ?? null,
      })
      .select('id')
      .single()

    if (error) return offline(error.message)

    // Update conversation timestamp
    await db
      .from('conversations')
      .update({ updated_at: new Date().toISOString() })
      .eq('id', conversationId)

    // Create notification for recipient
    await createNotification(member.user_id, 'message_received', me, undefined, undefined, undefined, undefined, conversationId)

    return error ? offline(error.message) : { ok: true, value: data.id }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function markMessagesRead(
  conversationId: string,
  userId: string,
): Promise<void> {
  const db = cloud()
  if (!db) return
  try {
    await db
      .from('messages')
      .update({ read_at: new Date().toISOString() })
      .eq('conversation_id', conversationId)
      .eq('recipient_id', userId)
      .is('read_at', null)
  } catch {
    // Silent fail - reading messages is not critical
  }
}

export async function markConversationRead(conversationId: string): Promise<void> {
  const db = cloud()
  if (!db) return
  const me = await myId()
  if (!me) return
  try {
    await db
      .from('messages')
      .update({ read_at: new Date().toISOString() })
      .eq('conversation_id', conversationId)
      .eq('recipient_id', me)
      .is('read_at', null)
  } catch {
    // Silent fail
  }
}

// ============================================
// DUELS
// ============================================

export async function createDuel(
  opponentId: string,
  exerciseId: ExerciseId,
  kind: DuelKind,
  durationSeconds?: number,
  targetReps?: number,
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()
  if (me === opponentId) {
    return { ok: false, reason: 'Cannot duel yourself.', code: 'invalid' }
  }

  try {
    const { data, error } = await db
      .from('duels')
      .insert({
        challenger_id: me,
        opponent_id: opponentId,
        exercise_id: exerciseId,
        kind,
        duration_seconds: durationSeconds ?? null,
        target_reps: targetReps ?? null,
        status: 'pending',
      })
      .select('id')
      .single()

    if (error) return offline(error.message)

    // Create notification for opponent
    await createNotification(opponentId, 'duel_invitation', me, undefined, data.id)

    return error ? offline(error.message) : { ok: true, value: data.id }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function acceptDuel(duelId: string): Promise<CloudResult<true>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { error } = await db
      .from('duels')
      .update({ status: 'accepted' })
      .eq('id', duelId)
      .eq('opponent_id', me)

    if (error) return offline(error.message)

    // Create notification for challenger
    const { data: duel } = await db
      .from('duels')
      .select('challenger_id')
      .eq('id', duelId)
      .maybeSingle()

    if (duel) {
      await createNotification(duel.challenger_id, 'duel_accepted', me, undefined, duelId)
    }

    return { ok: true, value: true }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function declineDuel(duelId: string): Promise<CloudResult<true>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { error } = await db
      .from('duels')
      .update({ status: 'declined' })
      .eq('id', duelId)
      .eq('opponent_id', me)

    if (error) return offline(error.message)

    // Notify challenger
    const { data: duel } = await db
      .from('duels')
      .select('challenger_id')
      .eq('id', duelId)
      .maybeSingle()

    if (duel) {
      await createNotification(duel.challenger_id, 'duel_declined', me, undefined, duelId)
    }

    return { ok: true, value: true }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function startDuel(duelId: string): Promise<CloudResult<true>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { error } = await db
      .from('duels')
      .update({
        status: 'in_progress',
        started_at: new Date().toISOString(),
      })
      .eq('id', duelId)
      .eq('challenger_id', me)

    // Also allow opponent to start
    if (error?.code === 'too_many_rows' || error?.code === 'PGRST109') {
      // Might have been updated by other side, check
    } else if (error) {
      return offline(error.message)
    }

    return { ok: true, value: true }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function submitDuelAttempt(
  duelId: string,
  workoutId: string,
  reps?: number,
  formScore?: number,
  durationSeconds?: number,
): Promise<CloudResult<true>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    // Get duel info
    const { data: duel } = await db
      .from('duels')
      .select('challenger_id, opponent_id, challenger_attempt_id, opponent_attempt_id')
      .eq('id', duelId)
      .maybeSingle()

    if (!duel) return { ok: false, reason: 'Duel not found.', code: 'not_found' }

    const isChallenger = duel.challenger_id === me
    const isOpponent = duel.opponent_id === me
    if (!isChallenger && !isOpponent) {
      return { ok: false, reason: 'You are not part of this duel.', code: 'unauthorized' }
    }

    const attemptId = isChallenger ? duel.challenger_attempt_id : duel.opponent_attempt_id

    if (attemptId) {
      // Update existing attempt
      const { error } = await db
        .from('duel_attempts')
        .update({
          workout_id: workoutId,
          reps: reps ?? null,
          form_score: formScore ?? null,
          duration_seconds: durationSeconds ?? null,
          recorded_at: new Date().toISOString(),
        })
        .eq('id', attemptId)

      if (error) return offline(error.message)
    } else {
      // Create new attempt
      const { data, error } = await db
        .from('duel_attempts')
        .insert({
          duel_id: duelId,
          user_id: me,
          workout_id: workoutId,
          reps: reps ?? null,
          form_score: formScore ?? null,
          duration_seconds: durationSeconds ?? null,
        })
        .select('id')
        .single()

      if (error) return offline(error.message)

      // Update duel with attempt ID
      const updateField = isChallenger ? 'challenger_attempt_id' : 'opponent_attempt_id'
      await db
        .from('duels')
        .update({ [updateField]: data.id })
        .eq('id', duelId)
    }

    // Check if both sides have submitted
    const { data: updatedDuel } = await db
      .from('duels')
      .select('challenger_attempt_id, opponent_attempt_id, status, challenger_id, opponent_id')
      .eq('id', duelId)
      .maybeSingle()

    if (updatedDuel && updatedDuel.challenger_attempt_id && updatedDuel.opponent_attempt_id) {
      // Both attempts submitted - determine winner
      await determineDuelWinner(duelId)
    }

    return { ok: true, value: true }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

async function determineDuelWinner(duelId: string): Promise<void> {
  const db = cloud()
  if (!db) return

  try {
    // Get duel with attempts
    const { data: duel } = await db
      .from('duels')
      .select(
        'challenger_id, opponent_id, kind, challenger_attempt_id, opponent_attempt_id',
      )
      .eq('id', duelId)
      .maybeSingle()

    if (!duel) return

    // Get both attempts
    const challengerAttempt = duel.challenger_attempt_id
      ? await getDuelAttempt(duel.challenger_attempt_id)
      : null
    const opponentAttempt = duel.opponent_attempt_id
      ? await getDuelAttempt(duel.opponent_attempt_id)
      : null

    if (!challengerAttempt || !opponentAttempt) return

    // Determine winner based on kind
    let winnerId: string | null = null

    switch (duel.kind) {
      case 'reps':
        winnerId =
          challengerAttempt.reps > opponentAttempt.reps
            ? duel.challenger_id
            : challengerAttempt.reps < opponentAttempt.reps
              ? duel.opponent_id
              : null // tie
        break
      case 'form':
        winnerId =
          (challengerAttempt.formScore ?? 0) > (opponentAttempt.formScore ?? 0)
            ? duel.challenger_id
            : (challengerAttempt.formScore ?? 0) < (opponentAttempt.formScore ?? 0)
              ? duel.opponent_id
              : null
        break
      case 'time':
        // Lower time is better
        winnerId =
          (challengerAttempt.durationSeconds ?? Infinity) < (opponentAttempt.durationSeconds ?? Infinity)
            ? duel.challenger_id
            : (challengerAttempt.durationSeconds ?? Infinity) > (opponentAttempt.durationSeconds ?? Infinity)
              ? duel.opponent_id
              : null
        break
      case 'max_reps':
        winnerId =
          challengerAttempt.reps > opponentAttempt.reps
            ? duel.challenger_id
            : challengerAttempt.reps < opponentAttempt.reps
              ? duel.opponent_id
              : null
        break
    }

    // Update duel status
    await db
      .from('duels')
      .update({
        status: winnerId ? 'completed' : 'completed', // still completed even if tie
        winner_id: winnerId,
        completed_at: new Date().toISOString(),
      })
      .eq('id', duelId)

    // Create notifications
    if (winnerId) {
      const loserId = winnerId === duel.challenger_id ? duel.opponent_id : duel.challenger_id
      await createNotification(winnerId, 'duel_won', loserId, undefined, duelId)
      await createNotification(loserId, 'duel_lost', winnerId, undefined, duelId)
    }
  } catch {
    // Silent fail - determination is best-effort
  }
}

async function getDuelAttempt(
  attemptId: string,
): Promise<DuelAttempt | null> {
  const db = cloud()
  if (!db) return null

  try {
    const { data } = await db
      .from('duel_attempts')
      .select('id, duel_id, user_id, workout_id, reps, form_score, duration_seconds, recorded_at')
      .eq('id', attemptId)
      .maybeSingle()

    if (!data) return null

    return {
      id: data.id,
      duelId: data.duel_id,
      userId: data.user_id,
      workoutId: data.workout_id,
      reps: data.reps,
      formScore: data.form_score,
      durationSeconds: data.duration_seconds,
      recordedAt: data.recorded_at,
    }
  } catch {
    return null
  }
}

export async function loadDuels(): Promise<Duel[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    const { data } = await db
      .from('duels')
      .select(
        'id, challenger_id, opponent_id, exercise_id, kind, duration_seconds, target_reps, status, challenger_attempt_id, opponent_attempt_id, winner_id, created_at, started_at, completed_at',
      )
      .or(`challenger_id.eq.${me},opponent_id.eq.${me}`)
      .order('created_at', { ascending: false })
      .limit(50)

    if (!data) return []

    // Get profiles and attempts
    const challengerIds = [...new Set(data.map((d) => d.challenger_id))]
    const opponentIds = [...new Set(data.map((d) => d.opponent_id))]
    const allUserIds = [...new Set([...challengerIds, ...opponentIds])]

    const profiles: Record<string, SocialProfile> = {}
    if (allUserIds.length > 0) {
      const { data: profileData } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', allUserIds)
      if (profileData) {
        for (const p of profileData) {
          profiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    // Get all attempts
    const attemptIds = [
      ...data.map((d) => d.challenger_attempt_id).filter(Boolean),
      ...data.map((d) => d.opponent_attempt_id).filter(Boolean),
    ] as string[]

    const attempts: Record<string, DuelAttempt> = {}
    if (attemptIds.length > 0) {
      const { data: attemptData } = await db
        .from('duel_attempts')
        .select('id, duel_id, user_id, workout_id, reps, form_score, duration_seconds, recorded_at')
        .in('id', attemptIds)

      if (attemptData) {
        for (const a of attemptData) {
          attempts[a.id] = {
            id: a.id,
            duelId: a.duel_id,
            userId: a.user_id,
            workoutId: a.workout_id,
            reps: a.reps,
            formScore: a.form_score,
            durationSeconds: a.duration_seconds,
            recordedAt: a.recorded_at,
          }
        }
      }
    }

    return data.map((d) => ({
      id: d.id,
      challengerId: d.challenger_id,
      opponentId: d.opponent_id,
      exerciseId: d.exercise_id as ExerciseId,
      kind: d.kind,
      durationSeconds: d.duration_seconds,
      targetReps: d.target_reps,
      status: d.status,
      challengerAttemptId: d.challenger_attempt_id,
      opponentAttemptId: d.opponent_attempt_id,
      winnerId: d.winner_id,
      createdAt: d.created_at,
      startedAt: d.started_at,
      completedAt: d.completed_at,
      challenger: profiles[d.challenger_id] ?? null,
      opponent: profiles[d.opponent_id] ?? null,
      challengerAttempt: d.challenger_attempt_id ? attempts[d.challenger_attempt_id] ?? null : null,
      opponentAttempt: d.opponent_attempt_id ? attempts[d.opponent_attempt_id] ?? null : null,
    }))
  } catch {
    return []
  }
}

// ============================================
// POSTS (Feed)
// ============================================

export async function createPost(
  type: PostType,
  title: string,
  options?: {
    body?: string
    exerciseId?: ExerciseId
    reps?: number
    formScore?: number
    streakDays?: number
    workoutId?: string
    duelId?: string
    challengeId?: string
    visibility?: Visibility
  },
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { data, error } = await db
      .from('posts')
      .insert({
        user_id: me,
        type,
        title: title.slice(0, 200),
        body: options?.body?.slice(0, 1000) ?? null,
        exercise_id: options?.exerciseId ?? null,
        reps: options?.reps ?? null,
        form_score: options?.formScore ?? null,
        streak_days: options?.streakDays ?? null,
        workout_id: options?.workoutId ?? null,
        duel_id: options?.duelId ?? null,
        challenge_id: options?.challengeId ?? null,
        visibility: options?.visibility ?? 'friends',
      })
      .select('id')
      .single()

    if (error) return offline(error.message)

    // If this was created from an activity, link them
    if (options?.workoutId) {
      // Find recent activity and link
      const { data: activity } = await db
        .from('social_activities')
        .select('id')
        .eq('user_id', me)
        .eq('workout_id', options.workoutId)
        .order('created_at', { ascending: false })
        .maybeSingle()

      if (activity) {
        await db
          .from('social_activities')
          .update({ post_id: data.id })
          .eq('id', activity.id)
      }
    }

    return error ? offline(error.message) : { ok: true, value: data.id }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function loadFeedPosts(limit = 30): Promise<Post[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    // Get friends list for visibility filtering
    const { data: friends } = await db
      .from('friendships')
      .select('user_id, friend_id')
      .or(`user_id.eq.${me},friend_id.eq.${me}`)

    const friendIds = friends
      ? friends
          .map((f) => (f.user_id === me ? f.friend_id : f.user_id))
          .filter(Boolean)
      : []

    // Get posts visible to this user
    const { data: posts } = await db
      .from('posts')
      .select(
        'id, user_id, type, title, body, exercise_id, reps, form_score, streak_days, workout_id, duel_id, challenge_id, likes_count, comments_count, visibility, created_at',
      )
      .or(
        friendIds.length > 0
          ? `user_id.in.(${friendIds.join(',')}),visibility.eq.public`
          : 'visibility.eq.public',
      )
      .neq('visibility', 'private')
      .order('created_at', { ascending: false })
      .limit(limit)

    if (!posts) return []

    // Get user profiles
    const userIds = [...new Set(posts.map((p) => p.user_id))]
    const profiles: Record<string, SocialProfile> = {}

    if (userIds.length > 0) {
      const { data: profileData } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', userIds)
      if (profileData) {
        for (const p of profileData) {
          profiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    // Get like status for current user
    const { data: likes } = await db
      .from('post_likes')
      .select('post_id, user_id')
      .eq('user_id', me)
      .in('post_id', posts.map((p) => p.id))

    const likedPosts = new Set<string>()
    if (likes) {
      for (const like of likes) {
        likedPosts.add(like.post_id)
      }
    }

    // Get comments count (already have count in posts, but could load comments)
    return posts.map((p) => ({
      id: p.id,
      userId: p.user_id,
      type: p.type,
      title: p.title,
      body: p.body,
      exerciseId: p.exercise_id as ExerciseId | null,
      reps: p.reps,
      formScore: p.form_score,
      streakDays: p.streak_days,
      workoutId: p.workout_id,
      duelId: p.duel_id,
      challengeId: p.challenge_id,
      likesCount: p.likes_count,
      commentsCount: p.comments_count,
      visibility: p.visibility as Visibility,
      createdAt: p.created_at,
      user: profiles[p.user_id] ?? null,
      isLiked: likedPosts.has(p.id),
    }))
  } catch {
    return []
  }
}

export async function togglePostLike(postId: string): Promise<CloudResult<boolean>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { data, error } = await db.rpc('toggle_post_like', { p_post_id: postId })
    return error ? offline(error.message) : { ok: true, value: data }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function addPostComment(
  postId: string,
  body: string,
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()
  if (!body || body.trim().length === 0 || body.trim().length > 500) {
    return { ok: false, reason: 'Comment must be between 1 and 500 characters.', code: 'invalid' }
  }

  try {
    const { data, error } = await db.rpc('add_post_comment', {
      p_post_id: postId,
      p_body: body.trim(),
    })
    return error ? offline(error.message) : { ok: true, value: data }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function loadPostComments(postId: string): Promise<PostComment[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    const { data } = await db
      .from('post_comments')
      .select('id, post_id, user_id, body, created_at')
      .eq('post_id', postId)
      .order('created_at', { ascending: true })
      .limit(50)

    if (!data) return []

    // Get user profiles
    const userIds = [...new Set(data.map((c) => c.user_id))]
    const profiles: Record<string, SocialProfile> = {}

    if (userIds.length > 0) {
      const { data: profileData } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', userIds)
      if (profileData) {
        for (const p of profileData) {
          profiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    return data.map((c) => ({
      id: c.id,
      postId: c.post_id,
      userId: c.user_id,
      body: c.body,
      createdAt: c.created_at,
      user: profiles[c.user_id] ?? null,
    }))
  } catch {
    return []
  }
}

// ============================================
// NOTIFICATIONS
// ============================================

export async function loadNotifications(limit = 50): Promise<Notification[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    const { data } = await db
      .from('notifications')
      .select(
        'id, user_id, type, from_user_id, conversation_id, duel_id, challenge_id, workout_id, post_id, read_at, created_at',
      )
      .eq('user_id', me)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (!data) return []

    // Get from-user profiles
    const fromUserIds = [...new Set(data.map((n) => n.from_user_id).filter(Boolean))] as string[]
    const profiles: Record<string, SocialProfile> = {}

    if (fromUserIds.length > 0) {
      const { data: profileData } = await db
        .from('profiles')
        .select('id, username, display_name, bio, accent, avatar, avatar_url, level, streak, shown_badges, thrive_code, visibility')
        .in('id', fromUserIds)
      if (profileData) {
        for (const p of profileData) {
          profiles[p.id] = {
            id: p.id,
            username: p.username,
            displayName: p.display_name,
            bio: p.bio,
            accent: p.accent,
            avatar: p.avatar,
            avatarUrl: p.avatar_url,
            level: p.level ?? 1,
            streak: p.streak ?? 0,
            shownBadges: p.shown_badges ?? [],
            thriveCode: p.thrive_code,
            visibility: (p.visibility as Visibility) ?? 'friends',
          }
        }
      }
    }

    return data.map((n) => ({
      id: n.id,
      userId: n.user_id,
      type: n.type,
      fromUserId: n.from_user_id,
      conversationId: n.conversation_id,
      duelId: n.duel_id,
      challengeId: n.challenge_id,
      workoutId: n.workout_id,
      postId: n.post_id,
      readAt: n.read_at,
      createdAt: n.created_at,
      fromUser: n.from_user_id ? profiles[n.from_user_id] ?? null : null,
    }))
  } catch {
    return []
  }
}

export async function createNotification(
  userId: string,
  type: NotificationType,
  fromUserId?: string | null,
  duelId?: string | null,
  challengeId?: string | null,
  workoutId?: string | null,
  postId?: string | null,
  conversationId?: string | null,
): Promise<void> {
  const db = cloud()
  if (!db) return

  try {
    await db.from('notifications').insert({
      user_id: userId,
      type,
      from_user_id: fromUserId ?? null,
      duel_id: duelId ?? null,
      challenge_id: challengeId ?? null,
      workout_id: workoutId ?? null,
      post_id: postId ?? null,
      conversation_id: conversationId ?? null,
    })
  } catch {
    // Silent fail - notifications are best-effort
  }
}

export async function markNotificationsRead(): Promise<void> {
  const db = cloud()
  if (!db) return
  const me = await myId()
  if (!me) return

  try {
    await db.rpc('mark_notifications_read')
  } catch {
    // Silent fail
  }
}

// ============================================
// SOCIAL ACTIVITIES
// ============================================

export async function createSocialActivity(
  type: ActivityType,
  options?: {
    exerciseId?: ExerciseId
    reps?: number
    formScore?: number
    streakDays?: number
    workoutId?: string
    duelId?: string
    challengeId?: string
  },
): Promise<CloudResult<string>> {
  const db = cloud()
  if (!db) return offline()
  const me = await myId()
  if (!me) return notSignedIn()

  try {
    const { data, error } = await db
      .from('social_activities')
      .insert({
        user_id: me,
        type,
        exercise_id: options?.exerciseId ?? null,
        reps: options?.reps ?? null,
        form_score: options?.formScore ?? null,
        streak_days: options?.streakDays ?? null,
        workout_id: options?.workoutId ?? null,
        duel_id: options?.duelId ?? null,
        challenge_id: options?.challengeId ?? null,
      })
      .select('id')
      .single()

    if (error) return offline(error.message)

    return error ? offline(error.message) : { ok: true, value: data.id }
  } catch (thrown) {
    return offline(String(thrown))
  }
}

export async function loadRecentActivities(limit = 20): Promise<SocialActivity[]> {
  const db = cloud()
  if (!db) return []
  const me = await myId()
  if (!me) return []

  try {
    const { data } = await db
      .from('social_activities')
      .select(
        'id, user_id, type, exercise_id, reps, form_score, streak_days, workout_id, duel_id, challenge_id, post_id, created_at',
      )
      .eq('user_id', me)
      .order('created_at', { ascending: false })
      .limit(limit)

    if (!data) return []

    return data.map((a) => ({
      id: a.id,
      userId: a.user_id,
      type: a.type,
      exerciseId: a.exercise_id as ExerciseId | null,
      reps: a.reps,
      formScore: a.form_score,
      streakDays: a.streak_days,
      workoutId: a.workout_id,
      duelId: a.duel_id,
      challengeId: a.challenge_id,
      postId: a.post_id,
      createdAt: a.created_at,
    }))
  } catch {
    return []
  }
}

// ============================================
// HELPERS
// ============================================

export function formatNotification(
  notification: Notification,
): { title: string; body: string; actionUrl?: string } {
  const fromUser = notification.fromUser
  const fromName = fromUser?.displayName || fromUser?.username || 'Someone'

  switch (notification.type) {
    case 'friend_request_sent':
      return {
        title: 'Friend request sent',
        body: `You sent a friend request to ${fromName}.`,
        actionUrl: `/connect/${notification.fromUserId}`,
      }
    case 'friend_request_accepted':
      return {
        title: 'Friend request accepted',
        body: `${fromName} accepted your friend request.`,
        actionUrl: `/connect/${notification.fromUserId}`,
      }
    case 'friend_request_declined':
      return {
        title: 'Friend request declined',
        body: `${fromName} declined your friend request.`,
      }
    case 'friend_added':
      return {
        title: 'New friend',
        body: `${fromName} is now your friend.`,
        actionUrl: `/connect/${notification.fromUserId}`,
      }
    case 'message_received':
      return {
        title: 'New message',
        body: 'You have a new message.',
        actionUrl: `/messages/${notification.conversationId}`,
      }
    case 'duel_invitation':
      return {
        title: 'Duel invitation',
        body: `${fromName} challenged you to a duel.`,
        actionUrl: `/duels/${notification.duelId}`,
      }
    case 'duel_accepted':
      return {
        title: 'Duel accepted',
        body: `${fromName} accepted your duel challenge.`,
        actionUrl: `/duels/${notification.duelId}`,
      }
    case 'duel_declined':
      return {
        title: 'Duel declined',
        body: `${fromName} declined your duel challenge.`,
      }
    case 'duel_completed':
      return {
        title: 'Duel completed',
        body: 'A duel you were in has been completed.',
        actionUrl: `/duels/${notification.duelId}`,
      }
    case 'challenge_invitation':
      return {
        title: 'Challenge invitation',
        body: 'You have a new challenge invitation.',
        actionUrl: '/challenges',
      }
    case 'challenge_accepted':
      return {
        title: 'Challenge accepted',
        body: 'Your challenge was accepted.',
        actionUrl: '/challenges',
      }
    case 'challenge_completed':
      return {
        title: 'Challenge completed',
        body: 'A challenge you were in has been completed.',
        actionUrl: '/challenges',
      }
    case 'friend_pr':
      return {
        title: 'New personal record',
        body: `${fromName} achieved a new personal record.`,
        actionUrl: `/connect/${notification.fromUserId}`,
      }
    case 'friend_streak':
      return {
        title: 'Streak milestone',
        body: `${fromName} reached a new streak milestone.`,
        actionUrl: `/connect/${notification.fromUserId}`,
      }
    case 'post_liked':
      return {
        title: 'Post liked',
        body: `${fromName} liked your post.`,
        actionUrl: `/feed`,
      }
    case 'post_comment':
      return {
        title: 'New comment',
        body: `${fromName} commented on your post.`,
        actionUrl: `/feed`,
      }
    case 'workout_shared':
      return {
        title: 'Workout shared',
        body: `${fromName} shared a new workout.`,
        actionUrl: `/feed`,
      }
    case 'duel_won':
      return {
        title: 'Duel won',
        body: `Congratulations! You won a duel.`,
        actionUrl: `/duels/${notification.duelId}`,
      }
    case 'duel_lost':
      return {
        title: 'Duel lost',
        body: `Better luck next time. You lost a duel.`,
        actionUrl: `/duels/${notification.duelId}`,
      }
    default:
      return {
        title: 'Notification',
        body: 'You have a new notification.',
      }
  }
}

import { createFileRoute } from '@tanstack/react-router'
import { FriendsScreen } from '@/components/screens/FriendsScreen'

/**
 * Friends: your training community.
 *
 * Friend list, requests, search, and profiles.
 */
export const Route = createFileRoute('/friends')({ component: FriendsScreen })

import { createFileRoute, useParams, useNavigate } from '@tanstack/react-router'
import { FriendProfileScreen } from '@/components/screens/FriendProfileScreen'

function FriendProfileRoute() {\n  const { userId } = useParams({ from: '/friends/$userId' })\n  const navigate = useNavigate()\n  return (\n    <FriendProfileScreen\n      userId={userId}\n      onGone={() => void navigate({ to: '/friends' })}\n    />\n  )\n}\n\nexport const Route = createFileRoute('/friends/$userId')({ component: FriendProfileRoute })\n
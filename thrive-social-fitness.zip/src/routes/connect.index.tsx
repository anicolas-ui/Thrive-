import { createFileRoute, redirect } from '@tanstack/react-router';

/**
 * Redirect /connect to /friends
 */
export const Route = createFileRoute('/connect/')({
  component: () => null,
  beforeLoad: () => {
    throw redirect({ to: '/friends' });
  },
});

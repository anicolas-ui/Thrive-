import { createFileRoute, useParams } from '@tanstack/react-router'
import { ConversationScreen } from '@/components/screens/ConversationScreen'

function ConversationRoute() {\n  const { conversationId } = useParams({ from: '/messages/$conversationId' })\n  return <ConversationScreen conversationId={conversationId} />\n}\n\nexport const Route = createFileRoute('/messages/$conversationId')({ component: ConversationRoute })\n
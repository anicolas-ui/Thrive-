import { createFileRoute } from '@tanstack/react-router'
import { MessagesScreen } from '@/components/screens/MessagesScreen'

/**
 * Messages: real-time conversations with friends.
 */
export const Route = createFileRoute('/messages')({ component: MessagesScreen })

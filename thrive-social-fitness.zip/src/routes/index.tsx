import { createFileRoute, redirect } from '@tanstack/react-router';

/**
 * Root route redirects to home.
 */
export const Route = createFileRoute('/')({
  component: () => {
    return null;
  },
  beforeLoad: () => {
    throw redirect({ to: '/home' });
  },
});

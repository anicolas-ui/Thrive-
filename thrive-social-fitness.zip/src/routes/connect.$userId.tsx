import { createFileRoute, redirect, useParams } from '@tanstack/react-router';
import { FriendProfileScreen } from '@/components/screens/FriendProfileScreen';
import { useNavigate } from '@tanstack/react-router';

function FriendProfileRoute() {
  const { userId } = useParams({ from: '/connect/$userId' });
  const navigate = useNavigate();
  return (
    <FriendProfileScreen
      userId={userId}
      onGone={() => void navigate({ to: '/friends' })}
    />
  );
}

export const Route = createFileRoute('/connect/$userId')({
  component: FriendProfileRoute,
  beforeLoad: () => {
    // Allow access but the URL will still have /connect/$userId
    // For a full redirect, we'd need to update the browser URL
  },
});

import { createFileRoute } from '@tanstack/react-router'
import { HomeScreen } from '@/components/screens/HomeScreen'

/**
 * Home: the social fitness dashboard.
 *
 * The first thing users see — answers:
 * - What should I do today?
 * - What are my friends doing?
 * - Do I have anything waiting for me?
 */
export const Route = createFileRoute('/home')({ component: HomeScreen })

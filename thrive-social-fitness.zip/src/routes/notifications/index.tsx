import { createFileRoute } from '@tanstack/react-router'
import { NotificationsScreen } from '@/components/screens/NotificationsScreen'

/**
 * Notifications: your notification center.
 *
 * Real-time updates for:
 * - Friend requests
 * - Messages
 * - Duel invitations/results
 * - Challenge updates
 * - Friend achievements
 * - Post reactions
 */
export const Route = createFileRoute('/notifications')({ component: NotificationsScreen })

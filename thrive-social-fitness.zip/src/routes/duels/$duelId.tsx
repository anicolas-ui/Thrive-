import { createFileRoute, useParams } from '@tanstack/react-router'
import { DuelDetailScreen } from '@/components/screens/DuelDetailScreen'

function DuelDetailRoute() {\n  const { duelId } = useParams({ from: '/duels/$duelId' })\n  return <DuelDetailScreen duelId={duelId} />\n}\n\nexport const Route = createFileRoute('/duels/$duelId')({ component: DuelDetailRoute })\n
import { createFileRoute } from '@tanstack/react-router'
import { DuelsScreen } from '@/components/screens/DuelsScreen'

/**
 * Duels: 1v1 fitness competitions with friends.
 *
 * Duel flow:
 * 1. Select friend
 * 2. Select exercise
 * 3. Select duel type
 * 4. Send invitation
 * 5. Friend accepts/declines
 * 6. Each person completes attempt
 * 7. Results compared
 * 8. Winner displayed
 * 9. Both can share to feed
 */
export const Route = createFileRoute('/duels')({ component: DuelsScreen })

import { createFileRoute } from '@tanstack/react-router'
import { ProfileScreen } from '@/components/screens/ProfileScreen'

/**
 * Profile: your fitness identity.
 *
 * Your stats, achievements, settings, and privacy controls.
 */
export const Route = createFileRoute('/profile')({ component: ProfileScreen })

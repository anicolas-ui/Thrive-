# Thrive - Social Fitness Platform

A premium, mobile-first social fitness platform built with React, TanStack Router, Supabase, and MediaPipe.

## What's Included

### New Features Added
1. **Home Dashboard** - Social fitness dashboard with streak, friend activity, active duels
2. **Real-time Messaging** - Conversation list and individual chat screens
3. **Duels System** - 1v1 fitness competitions with full duel flow
4. **Social Feed** - Posts with likes, comments, shares
5. **Notification Center** - Real-time social notifications
6. **Enhanced Profiles** - Stats, PRs, favorite exercises, duel history

### Files Added/Modified

**New Library Files:**
- `src/lib/thrive/socialFitness.ts` - All social operations (conversations, duels, posts, notifications)
- `src/lib/thrive/socialTypes.ts` - TypeScript types for social features

**New Routes (9):**
- `src/routes/home/` - Home dashboard
- `src/routes/messages/` - Messages list and conversation
- `src/routes/duels/` - Duels list and detail
- `src/routes/friends/` - Friends list and profile
- `src/routes/notifications/` - Notification center
- `src/routes/profile/` - User profile

**New Screen Components (10):**
- `src/components/screens/HomeScreen.tsx`
- `src/components/screens/MessagesScreen.tsx`
- `src/components/screens/ConversationScreen.tsx`
- `src/components/screens/DuelsScreen.tsx`
- `src/components/screens/DuelDetailScreen.tsx`
- `src/components/screens/FriendsScreen.tsx`
- `src/components/screens/FriendProfileScreen.tsx`
- `src/components/screens/FeedScreen.tsx`
- `src/components/screens/NotificationsScreen.tsx`
- `src/components/screens/ProfileScreen.tsx`

**Modified Files:**
- `src/components/app/TabBar.tsx` - Updated navigation with 7 tabs
- `src/routes/index.tsx` - Redirect to /home
- `src/routes/connect.*.tsx` - Redirect to /friends
- `src/routeTree.gen.ts` - Updated route tree

**Database Migration:**
- `supabase/migrations/0002_social_fitness.sql` - Complete social schema

## Database Setup

### Run Migrations in Order:

1. **First migration** (if not already run):
   ```sql
   -- supabase/migrations/0001_social.sql
   ```

2. **Second migration** (new social features):
   ```sql
   -- supabase/migrations/0002_social_fitness.sql
   ```

### Database Features Added:

**Conversations & Messages:**
- `conversations` table
- `conversation_members` table
- Real-time subscriptions enabled
- Helper functions: `get_or_create_conversation`, `mark_notifications_read`

**Duels:**
- `duels` table (1v1 competitions)
- `duel_attempts` table (each player's attempt)
- Duel kinds: reps, form, time, max_reps
- Auto winner determination

**Social Features:**
- `posts` table (feed items)
- `post_likes` table
- `post_comments` table
- `notifications` table
- `social_activities` table (for auto-generated posts)

**Helper Functions:**
- `create_notification()` - Create notifications
- `create_post_from_activity()` - Convert activity to post
- `toggle_post_like()` - Like/unlike posts
- `add_post_comment()` - Add comments

## Navigation Structure

The app now has 7 main tabs:

1. **Home** (`/home`) - Dashboard
2. **Train** (`/train`) - Exercise selection (existing)
3. **Feed** (`/feed`) - Social feed
4. **Friends** (`/friends`) - Friend list
5. **Messages** (`/messages`) - Conversations
6. **Duels** (`/duels`) - Competitions
7. **Profile** (`/profile`) - Your profile

## Usage

### Development

```bash
npm install
npm run dev
```

### Build

```bash
npm run build
```

### Type Check

```bash
npm run typecheck
```

## Architecture

### Core Loop
TRAIN → COMPLETE WORKOUT → SHARE RESULT → FRIENDS REACT → CHALLENGE/DUEL → TRAIN AGAIN

### Key Features

**Home Dashboard:**
- Greeting based on time of day
- Current streak display
- Workouts this week
- Badges earned
- Active duels
- Pending challenges
- Friend activity
- Quick actions (Feed, Messages, Duels, Add Friend)

**Messaging:**
- Real-time via Supabase subscriptions
- Conversation list with unread counts
- Individual chat with message bubbles
- Send messages with workout/challenge attachments
- Mark as read on view

**Duels:**
- Create duel: select friend → exercise → duel type
- Accept/decline invitations
- Record attempts from workout history
- Auto-determined winner
- Result sharing

**Feed:**
- Posts from workouts, PRs, streaks, duels, challenges
- Like/unlike with real-time updates
- Comments with real-time updates
- Share via native share API
- Challenge button to start duel

**Notifications:**
- Real-time updates for all social events
- Unread indicator
- Mark all read
- Tap to navigate

**Profiles:**
- Stats (streak, workouts, reps, badges)
- Personal records per exercise
- Favorite exercises
- Recent activity
- Duel history
- Privacy settings

## Environment Setup

Create a `.env` file with your Supabase credentials:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
```

See `.env.example` for reference.

## Existing Features Preserved

All existing functionality remains intact:
- MediaPipe pose analysis (squat, push-up, pull-up, curl)
- Real-time rep counting and form scoring
- Workout history
- Progress tracking
- Badges and tiers
- Coach chat
- Friend system (existing)
- Challenges (existing)
- Share code system
